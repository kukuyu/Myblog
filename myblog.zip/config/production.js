module.exports = {
  port:80,
  mongodb: 'mongodb://localhost/myblog'
};